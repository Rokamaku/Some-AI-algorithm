
public class PendulumController implements Runnable 
{
	protected Pendulum pendulum;
	
	public PendulumController(Pendulum P)
	{
		pendulum = P;
	}
	
	public void run()
	{
		double[] pState = new double[4];
		
		// Repeat forever
		while (true) {
			// DO NOT CHANGE
			// Current Pendulum State
			pendulum.getPendulumState(pState);
			double X = pState[0];
			double dX = pState[1];
			double Theta = pState[2];
			double dTheta = pState[3];
			
			// REPLACE WITH YOUR CODE
			
			// Actual Controller Code Here:
			// The dumbest possible bang-bang Controller
			if (Theta > 0) pendulum.setMotorForce(-1.0);
			else           pendulum.setMotorForce(1.0);
		
			// DO NOT CHANGE
			// Put the thread to sleep for a few milliseconds to avoid busy waiting
			try {
				Thread.sleep(10);
			} catch (Exception e) {
			}
		}
	}
}








